# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "My Addon",
    "author" : "Seba", 
    "description" : "",
    "blender" : (4, 2, 0),
    "version" : (1, 0, 3),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None
class SNA_PT_TITANFORGE_E3136(bpy.types.Panel):
    bl_label = 'Titan-Forge'
    bl_idname = 'SNA_PT_TITANFORGE_E3136'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Titan-Forge'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_31667 = layout.column(heading='sad', align=True)
        col_31667.alert = False
        col_31667.enabled = True
        col_31667.active = True
        col_31667.use_property_split = False
        col_31667.use_property_decorate = False
        col_31667.scale_x = 1.0
        col_31667.scale_y = 1.0
        col_31667.alignment = 'Expand'.upper()
        col_31667.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_7185A = col_31667.box()
        box_7185A.alert = False
        box_7185A.enabled = True
        box_7185A.active = True
        box_7185A.use_property_split = False
        box_7185A.use_property_decorate = False
        box_7185A.alignment = 'Expand'.upper()
        box_7185A.scale_x = 1.0
        box_7185A.scale_y = 1.0
        if not True: box_7185A.operator_context = "EXEC_DEFAULT"
        op = box_7185A.operator('sna.seperatbymaterial_0d494', text='SeperatByMaterial', icon_value=140, emboss=True, depress=False)
        op = box_7185A.operator('sna.attachedtoarmature_d85de', text='attachedtoarmature', icon_value=175, emboss=True, depress=False)


class SNA_OT_Seperatbymaterial_0D494(bpy.types.Operator):
    bl_idname = "sna.seperatbymaterial_0d494"
    bl_label = "SeperatByMaterial"
    bl_description = "SeperatByMaterial"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        obj = bpy.context.active_object
        if obj and obj.type == 'MESH':
            bpy.ops.object.mode_set(mode='EDIT')         # Go to Edit Mode
            bpy.ops.mesh.select_all(action='SELECT')     # Select all geometry
            bpy.ops.mesh.separate(type='MATERIAL')       # Separate by material
            bpy.ops.object.mode_set(mode='OBJECT')       # Return to Object Mode
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        else:
            print("No active mesh object selected.")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Attachedtoarmature_D85De(bpy.types.Operator):
    bl_idname = "sna.attachedtoarmature_d85de"
    bl_label = "attachedtoarmature"
    bl_description = "attachedtoarmature"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import mathutils
        # Get selected objects and identify the armature
        selected = bpy.context.selected_objects
        armature = next((obj for obj in selected if obj.type == 'ARMATURE'), None)
        objects = [obj for obj in selected if obj.type == 'MESH']
        if not armature:
            print("No armature selected!")
        else:
            bpy.ops.object.select_all(action='DESELECT')
            constraints_to_update = []
            for obj in objects:
                bpy.context.view_layer.objects.active = obj
                obj.select_set(True)
                try:
                    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='BOUNDS')
                except Exception as e:
                    print(f"Failed to set origin for {obj.name}: {e}")
                obj_loc = obj.matrix_world.translation
                closest_bone = None
                min_dist = float('inf')
                for pbone in armature.pose.bones:
                    if pbone.bone.use_deform:
                        bone_world_pos = armature.matrix_world @ pbone.head
                        dist = (obj_loc - bone_world_pos).length
                        if dist < min_dist:
                            min_dist = dist
                            closest_bone = pbone
                if closest_bone:
                    # Remove existing Child Of constraints
                    for con in obj.constraints:
                        if con.type == 'CHILD_OF':
                            obj.constraints.remove(con)
                    # Add new Child Of constraint
                    con = obj.constraints.new(type='CHILD_OF')
                    con.name = f"Child Of {closest_bone.name}"
                    con.target = armature
                    con.subtarget = closest_bone.name
                    constraints_to_update.append((obj, con))
                    print(f"{obj.name} → {closest_bone.name} (Child Of constraint added)")
                else:
                    print(f"No deform bone found for {obj.name}")
            bpy.context.view_layer.update()
            # Now set inverse using Blender operator
            for obj, con in constraints_to_update:
                bpy.context.view_layer.objects.active = obj
                # Ensure only obj selected to avoid issues
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                try:
                    bpy.ops.constraint.childof_set_inverse(constraint=con.name, owner='OBJECT')
                    print(f"Inverse set for {obj.name}")
                except Exception as e:
                    print(f"Failed to set inverse for {obj.name}: {e}")
            # Reselect all processed objects at the end
            for obj in objects:
                obj.select_set(True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_PT_TITANFORGE_E3136)
    bpy.utils.register_class(SNA_OT_Seperatbymaterial_0D494)
    bpy.utils.register_class(SNA_OT_Attachedtoarmature_D85De)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_PT_TITANFORGE_E3136)
    bpy.utils.unregister_class(SNA_OT_Seperatbymaterial_0D494)
    bpy.utils.unregister_class(SNA_OT_Attachedtoarmature_D85De)
