# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Titan-Forge",
    "author" : "Sebastian", 
    "description" : "",
    "blender" : (4, 2, 0),
    "version" : (1, 0, 4),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews


addon_keymaps = {}
_icons = None


def sna_update_sna_latticeresolution_5E75F(self, context):
    sna_updated_prop = self.sna_latticeresolution
    PROP1 = int(sna_updated_prop[0])
    PROP2 = int(sna_updated_prop[1])
    PROP3 = int(sna_updated_prop[2])
    from mathutils import Vector

    def add_or_update_lattice_for_object(obj, margin=1.4):
        bbox_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        min_corner = Vector((min(c[0] for c in bbox_corners),
                             min(c[1] for c in bbox_corners),
                             min(c[2] for c in bbox_corners)))
        max_corner = Vector((max(c[0] for c in bbox_corners),
                             max(c[1] for c in bbox_corners),
                             max(c[2] for c in bbox_corners)))
        size = max_corner - min_corner
        center = min_corner + size / 2
        lattice_mod = None
        for mod in obj.modifiers:
            if mod.type == 'LATTICE':
                lattice_mod = mod
                break
        # Function to create a new lattice object and link to modifier

        def create_and_assign_lattice():
            lattice_data = bpy.data.lattices.new(name=f"Lattice_for_{obj.name}")
            lattice_obj = bpy.data.objects.new(name=f"Lattice_for_{obj.name}", object_data=lattice_data)
            bpy.context.collection.objects.link(lattice_obj)
            lattice_obj.location = center
            lattice_obj.scale = (size * margin) / 2
            lattice_obj.parent = obj
            lattice_obj.matrix_parent_inverse = obj.matrix_world.inverted()
            lattice_data.points_u = PROP1
            lattice_data.points_v = PROP2
            lattice_data.points_w = PROP3
            if lattice_mod is None:
                lattice_mod_local = obj.modifiers.new(name="Lattice", type='LATTICE')
            else:
                lattice_mod_local = lattice_mod
            lattice_mod_local.object = lattice_obj
            print(f"Created and assigned new lattice to {obj.name}")
            return lattice_obj
        if lattice_mod:
            if not lattice_mod.object or lattice_mod.object.type != 'LATTICE':
                # Lattice modifier exists but has no object – create one
                lattice_obj = create_and_assign_lattice()
            else:
                lattice_obj = lattice_mod.object
                # Always update resolution
                lattice_obj.data.points_u = PROP1
                lattice_obj.data.points_v = PROP2
                lattice_obj.data.points_w = PROP3
                # Only update transform if not already a child
                if lattice_obj.parent == obj:
                    print(f"Lattice for {obj.name} is child; skipping transform update.")
                else:
                    lattice_obj.location = center
                    lattice_obj.scale = (size * margin) / 2
                    lattice_obj.parent = obj
                    lattice_obj.matrix_parent_inverse = obj.matrix_world.inverted()
                    print(f"Updated lattice transform for {obj.name}")
                lattice_mod.object = lattice_obj
        else:
            # No modifier — create modifier and lattice
            create_and_assign_lattice()

    def add_or_update_lattices_for_selected_objects():
        selected_objs = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
        if not selected_objs:
            print("No mesh objects selected.")
            return
        for obj in selected_objs:
            add_or_update_lattice_for_object(obj)
    add_or_update_lattices_for_selected_objects()


class SNA_PT_TITANFORGEV104_6A15D(bpy.types.Panel):
    bl_label = 'Titan-Forgev1.0.4'
    bl_idname = 'SNA_PT_TITANFORGEV104_6A15D'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Titan-Forge'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_31667 = layout.column(heading='', align=False)
        col_31667.alert = False
        col_31667.enabled = True
        col_31667.active = True
        col_31667.use_property_split = False
        col_31667.use_property_decorate = False
        col_31667.scale_x = 1.0
        col_31667.scale_y = 1.0
        col_31667.alignment = 'Expand'.upper()
        col_31667.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_58896 = col_31667.box()
        box_58896.alert = False
        box_58896.enabled = True
        box_58896.active = True
        box_58896.use_property_split = False
        box_58896.use_property_decorate = False
        box_58896.alignment = 'Expand'.upper()
        box_58896.scale_x = 1.0
        box_58896.scale_y = 1.0
        if not True: box_58896.operator_context = "EXEC_DEFAULT"
        op = box_58896.operator('sna.exporttruescale_c617c', text='ExportTrueScale', icon_value=638, emboss=True, depress=False)
        op = box_58896.operator('sna.importtruescale_a8b5b', text='ImportTrueScale', icon_value=661, emboss=True, depress=False)
        box_7185A = layout.box()
        box_7185A.alert = False
        box_7185A.enabled = True
        box_7185A.active = True
        box_7185A.use_property_split = False
        box_7185A.use_property_decorate = False
        box_7185A.alignment = 'Expand'.upper()
        box_7185A.scale_x = 1.0
        box_7185A.scale_y = 1.0
        if not True: box_7185A.operator_context = "EXEC_DEFAULT"
        op = box_7185A.operator('mesh.separate', text='SeperatByMaterial', icon_value=140, emboss=True, depress=False)
        op.type = 'MATERIAL'
        op = box_7185A.operator('view3d.tool_shelf_titanforge_splitbyfacesets', text='SplitByFaceSets', icon_value=202, emboss=True, depress=False)
        op = layout.operator('sna.transfervertexgrupe_a9866', text='TransferVertexGrupe', icon_value=439, emboss=True, depress=False)
        op = layout.operator('sna.attachedtoarmature_d85de', text='attachedtoarmature', icon_value=175, emboss=True, depress=False)
        col_24202 = layout.column(heading='Lattice', align=True)
        col_24202.alert = False
        col_24202.enabled = True
        col_24202.active = True
        col_24202.use_property_split = False
        col_24202.use_property_decorate = False
        col_24202.scale_x = 1.0
        col_24202.scale_y = 1.0
        col_24202.alignment = 'Expand'.upper()
        col_24202.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        box_C9A60 = col_24202.box()
        box_C9A60.alert = False
        box_C9A60.enabled = True
        box_C9A60.active = True
        box_C9A60.use_property_split = False
        box_C9A60.use_property_decorate = False
        box_C9A60.alignment = 'Expand'.upper()
        box_C9A60.scale_x = 1.0
        box_C9A60.scale_y = 1.0
        if not True: box_C9A60.operator_context = "EXEC_DEFAULT"
        box_C9A60.label(text='Add Lattice', icon_value=450)
        box_C9A60.prop(bpy.context.scene, 'sna_latticeresolution', text='', icon_value=450, emboss=True, slider=False, toggle=True)


class SNA_OT_Seperatbymaterial_0D494(bpy.types.Operator):
    bl_idname = "sna.seperatbymaterial_0d494"
    bl_label = "SeperatByMaterial"
    bl_description = "SeperatByMaterial"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        obj = bpy.context.active_object
        if obj and obj.type == 'MESH':
            bpy.ops.object.mode_set(mode='EDIT')         # Go to Edit Mode
            bpy.ops.mesh.select_all(action='SELECT')     # Select all geometry
            bpy.ops.mesh.separate(type='MATERIAL')       # Separate by material
            bpy.ops.object.mode_set(mode='OBJECT')       # Return to Object Mode
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        else:
            print("No active mesh object selected.")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Attachedtoarmature_D85De(bpy.types.Operator):
    bl_idname = "sna.attachedtoarmature_d85de"
    bl_label = "attachedtoarmature"
    bl_description = "attachedtoarmature"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        import mathutils
        # Get selected objects and identify the armature
        selected = bpy.context.selected_objects
        armature = next((obj for obj in selected if obj.type == 'ARMATURE'), None)
        objects = [obj for obj in selected if obj.type == 'MESH']
        if not armature:
            print("No armature selected!")
        else:
            bpy.ops.object.select_all(action='DESELECT')
            constraints_to_update = []
            for obj in objects:
                bpy.context.view_layer.objects.active = obj
                obj.select_set(True)
                try:
                    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='BOUNDS')
                except Exception as e:
                    print(f"Failed to set origin for {obj.name}: {e}")
                obj_loc = obj.matrix_world.translation
                closest_bone = None
                min_dist = float('inf')
                for pbone in armature.pose.bones:
                    if pbone.bone.use_deform:
                        bone_world_pos = armature.matrix_world @ pbone.head
                        dist = (obj_loc - bone_world_pos).length
                        if dist < min_dist:
                            min_dist = dist
                            closest_bone = pbone
                if closest_bone:
                    # Remove existing Child Of constraints
                    for con in obj.constraints:
                        if con.type == 'CHILD_OF':
                            obj.constraints.remove(con)
                    # Add new Child Of constraint
                    con = obj.constraints.new(type='CHILD_OF')
                    con.name = f"Child Of {closest_bone.name}"
                    con.target = armature
                    con.subtarget = closest_bone.name
                    constraints_to_update.append((obj, con))
                    print(f"{obj.name} → {closest_bone.name} (Child Of constraint added)")
                else:
                    print(f"No deform bone found for {obj.name}")
            bpy.context.view_layer.update()
            # Now set inverse using Blender operator
            for obj, con in constraints_to_update:
                bpy.context.view_layer.objects.active = obj
                # Ensure only obj selected to avoid issues
                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                try:
                    bpy.ops.constraint.childof_set_inverse(constraint=con.name, owner='OBJECT')
                    print(f"Inverse set for {obj.name}")
                except Exception as e:
                    print(f"Failed to set inverse for {obj.name}: {e}")
            # Reselect all processed objects at the end
            for obj in objects:
                obj.select_set(True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Exporttruescale_C617C(bpy.types.Operator):
    bl_idname = "sna.exporttruescale_c617c"
    bl_label = "ExportTrueScale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.transform_apply('INVOKE_DEFAULT', scale=True)
        bpy.context.active_object.scale = (25.399999618530273, 25.399999618530273, 25.399999618530273)
        bpy.ops.scene.gob_export_button('INVOKE_DEFAULT', )
        bpy.context.active_object.scale = (1.0, 1.0, 1.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Importtruescale_A8B5B(bpy.types.Operator):
    bl_idname = "sna.importtruescale_a8b5b"
    bl_label = "ImportTrueScale"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.scene.gob_import('INVOKE_DEFAULT', )
        bpy.context.active_object.scale = (0.03937000036239624, 0.03937000036239624, 0.03937000036239624)
        bpy.ops.object.transform_apply('INVOKE_DEFAULT', scale=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Transfervertexgrupe_A9866(bpy.types.Operator):
    bl_idname = "sna.transfervertexgrupe_a9866"
    bl_label = "TransferVertexGrupe"
    bl_description = "TransferVertexGrupe"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):

        def transfer_weights_and_add_armature():
            context = bpy.context
            active_obj = context.active_object
            selected_objs = [obj for obj in context.selected_objects if obj != active_obj]
            if not active_obj or active_obj.type != 'MESH':
                print("Active object must be a mesh.")
                return
            # Find armature from active object's modifiers
            armature = None
            for mod in active_obj.modifiers:
                if mod.type == 'ARMATURE' and mod.object:
                    armature = mod.object
                    break
            if not armature:
                print("Active object has no armature modifier with an assigned armature.")
                return
            source_groups = [vg.name for vg in active_obj.vertex_groups]
            for target in selected_objs:
                if target.type != 'MESH':
                    print(f"Skipping non-mesh object: {target.name}")
                    continue
                # Ensure target has all vertex groups with same names
                for group_name in source_groups:
                    if group_name not in target.vertex_groups:
                        target.vertex_groups.new(name=group_name)
                # Add Data Transfer modifier
                dt_mod = target.modifiers.new(name="TransferWeights", type='DATA_TRANSFER')
                dt_mod.object = active_obj
                dt_mod.use_vert_data = True
                dt_mod.data_types_verts = {'VGROUP_WEIGHTS'}
                dt_mod.vert_mapping = 'NEAREST'
                # Apply the modifier
                bpy.context.view_layer.objects.active = target
                bpy.ops.object.modifier_apply(modifier=dt_mod.name)
                # Assign the armature to the object
                has_armature = False
                for mod in target.modifiers:
                    if mod.type == 'ARMATURE':
                        mod.object = armature
                        has_armature = True
                        break
                if not has_armature:
                    arm_mod = target.modifiers.new(name="Armature", type='ARMATURE')
                    arm_mod.object = armature
                print(f"Transferred weights and assigned armature to: {target.name}")
            # Set active object back
            bpy.context.view_layer.objects.active = active_obj
        # Run it
        transfer_weights_and_add_armature()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_latticeresolution = bpy.props.IntVectorProperty(name='LatticeResolution', description='', size=3, default=(3, 3, 3), subtype='NONE', update=sna_update_sna_latticeresolution_5E75F)
    bpy.utils.register_class(SNA_PT_TITANFORGEV104_6A15D)
    bpy.utils.register_class(SNA_OT_Seperatbymaterial_0D494)
    bpy.utils.register_class(SNA_OT_Attachedtoarmature_D85De)
    bpy.utils.register_class(SNA_OT_Exporttruescale_C617C)
    bpy.utils.register_class(SNA_OT_Importtruescale_A8B5B)
    bpy.utils.register_class(SNA_OT_Transfervertexgrupe_A9866)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_latticeresolution
    bpy.utils.unregister_class(SNA_PT_TITANFORGEV104_6A15D)
    bpy.utils.unregister_class(SNA_OT_Seperatbymaterial_0D494)
    bpy.utils.unregister_class(SNA_OT_Attachedtoarmature_D85De)
    bpy.utils.unregister_class(SNA_OT_Exporttruescale_C617C)
    bpy.utils.unregister_class(SNA_OT_Importtruescale_A8B5B)
    bpy.utils.unregister_class(SNA_OT_Transfervertexgrupe_A9866)
